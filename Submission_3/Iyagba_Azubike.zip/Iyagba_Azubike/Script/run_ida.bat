@echo off
setlocal enabledelayedexpansion

set "IDA=C:\Program Files\IDA Free\idag.exe"
set "BASE=C:\Users\REM\Desktop\EXTRACTED"

if not exist "%IDA%" (
    echo ERROR: IDA not found at:
    echo %IDA%
    pause
    exit /b
)

echo ==========================================
echo Malware Reverse Engineering Automation
echo ==========================================
echo.
echo Enter the folder name exactly as it appears.
echo Example: APT17 or Turla or FIN7
echo.
set /p "APT=Folder name: "

set "TARGET=%BASE%\%APT%"

if not exist "%TARGET%" (
    echo.
    echo ERROR: Folder not found:
    echo %TARGET%
    pause
    exit /b
)

echo.
echo Searching for executables in:
echo %TARGET%
echo.

set "FOUND_EXE="
for %%F in ("%TARGET%\*.exe") do (
    set "FOUND_EXE=%%~fF"
    goto :sample_found
)

echo No .exe found in %TARGET%
pause
exit /b

:sample_found
set "EXEFILE=%FOUND_EXE%"
set "SAMPLENAME=%~n1"
for %%A in ("%EXEFILE%") do set "SAMPLENAME=%%~nA"
set "OPCODEDIR=%TARGET%\opcode"
set "OPCODEFILE=%OPCODEDIR%\%SAMPLENAME%.opcode"
set "IDBFILE=%TARGET%\%SAMPLENAME%.idb"
set "I64FILE=%TARGET%\%SAMPLENAME%.i64"

echo Sample found:
echo %EXEFILE%
echo.

if exist "%OPCODEFILE%" (
    echo Existing opcode file found:
    echo %OPCODEFILE%
    echo Opening .opcode in IDA...
    start "" "%IDA%" "%OPCODEFILE%"
    echo.
    echo IDA was started with the existing opcode file.
    pause
    exit /b
)

if exist "%I64FILE%" (
    echo Existing IDA database found:
    echo %I64FILE%
    echo Opening original sample so you can choose "Load existing" in IDA...
    start "" "%IDA%" "%EXEFILE%"
    echo.
    echo When IDA asks, choose "Load existing".
    pause
    exit /b
)

if exist "%IDBFILE%" (
    echo Existing IDA database found:
    echo %IDBFILE%
    echo Opening original sample so you can choose "Load existing" in IDA...
    start "" "%IDA%" "%EXEFILE%"
    echo.
    echo When IDA asks, choose "Load existing".
    pause
    exit /b
)

echo No existing opcode or IDA database found.
echo Opening executable for fresh analysis...
start "" "%IDA%" "%EXEFILE%"
echo.
echo If this is your first time analyzing it, continue normally.
pause
exit /b